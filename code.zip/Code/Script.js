// Toggle Hamburger Menu
function toggleMenu() {
    const navMenu = document.getElementById('nav-menu');
    navMenu.classList.toggle('active');
}

// Show Subject Content
function showContent() {
    const selector = document.getElementById('subjectSelector');
    const subjects = ['chemistry', 'physics', 'biology'];
    
    subjects.forEach(subject => {
        const content = document.getElementById(subject);
        content.style.display = subject === selector.value ? 'block' : 'none';
    });
}

// Scroll to Subjects
function scrollToSubjects() {
    document.getElementById('subjects').scrollIntoView({ behavior: 'smooth' });
}

// Check Science Quiz
function checkScienceQuiz() {
    const form = document.getElementById('science-quiz');
    const result = document.getElementById('quiz-result');
    const answers = {
        q1: 'b', // ग्लूकोज
        q2: 'b', // प्रतिकर्षित
        q3: 'b', // लवण और पानी
        q4: 'b', // रेटिना
        q5: 'b'  // मटर
    };
    let score = 0;
    let feedback = '';

    for (let i = 1; i <= 5; i++) {
        const answer = form.querySelector(`input[name="q${i}"]:checked`);
        if (answer) {
            if (answer.value === answers[`q${i}`]) {
                score++;
                feedback += `<p style="color: #00ff88;">प्रश्न ${i}: सही जवाब!</p>`;
            } else {
                feedback += `<p style="color: #ff4444;">प्रश्न ${i}: गलत! सही जवाब: ${
                    i === 1 ? 'ग्लूकोज' :
                    i === 2 ? 'प्रतिकर्षित' :
                    i === 3 ? 'लवण और पानी' :
                    i === 4 ? 'रेटिना' : 'मटर'
                }.</p>`;
            }
        } else {
            feedback += `<p style="color: #ff4444;">प्रश्न ${i}: कृपया जवाब चुनें!</p>`;
        }
    }

    result.innerHTML = `<p>आपका स्कोर: ${score}/5</p>${feedback}`;
}

// Reset Science Quiz
function resetScienceQuiz() {
    const form = document.getElementById('science-quiz');
    const result = document.getElementById('quiz-result');
    form.reset();
    result.innerHTML = '';
}

// Ask Questions Function
function submitQuestion() {
    const questionInput = document.getElementById('user-question');
    const answerDisplay = document.getElementById('answer-display');
    const question = questionInput.value.trim();

    if (!question) {
        answerDisplay.innerHTML = '<p style="color: #ff4444;">कृपया एक सवाल टाइप करें!</p>';
        return;
    }

    answerDisplay.innerHTML = '<p>प्रसंस्करण हो रहा है...</p>';
    
    setTimeout(() => {
        let answer = getDemoAnswer(question);
        answerDisplay.innerHTML = `<p>${answer}</p>`;
        questionInput.value = '';
    }, 1000);
}

// डेमो जवाब फंक्शन
function getDemoAnswer(question) {
    question = question.toLowerCase();
    if (question.includes('चुंबक') || question.includes('ध्रुव')) {
        return 'चुंबक के दो ध्रुव होते हैं: उत्तरी (N) और दक्षिणी (S)। समान ध्रुव प्रतिकर्षित करते हैं, और विपरीत ध्रुव आकर्षित करते हैं। चुंबकत्व पृथ्वी के कम्पास और MRI मशीनों में भी काम करता है!';
    } else if (question.includes('प्रकाश') || question.includes('गति')) {
        return 'प्रकाश की गति 3,00,000 किमी/सेकंड है, जो ब्रह्मांड में सबसे तेज़ है। गति भौतिक विज्ञान में स्थिति बदलने की दर है, जैसे कार का 60 किमी/घंटा चलना। और सवाल हो तो पूछो!';
    } else if (question.includes('आकाश') || question.includes('नीला')) {
        return 'आकाश नीला दिखता है क्योंकि पृथ्वी का वायुमंडल सूर्य के प्रकाश को प्रकीर्णन करता है। नीली रोशनी की तरंगदैर्ध्य छोटी होती है, इसलिए वह ज़्यादा बिखरती है। इसे रेले प्रकीर्णन कहते हैं!';
    } else {
        return 'यह एक शानदार सवाल है! मैं इसे और समझने के लिए डेटा खोज रहा हूँ। कृपया सवाल को और स्पष्ट करें या दूसरा सवाल पूछें। 😊';
    }
}